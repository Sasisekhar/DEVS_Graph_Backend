# Contributing to Cadmium 2
We are still working on this.
