#include "dhrystone.hpp"

namespace cadmium::example::devstone {
	void runDhrystone(int millis) {
		// TODO
	}
}  //namespace cadmium::example::devstone
